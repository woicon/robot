<template>
    <div id="notfound">
    </div>
</template>
<script>
export default {
    
}
</script>
